//
//  ViewController.h
//  HelloWatch
//
//  Created by Marcos Vinicius Albuquerque on 05/08/15.
//  Copyright (c) 2015 Marcos Vinicius Albuquerque. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

